"""Paperclip — Paper CLI for Preprints + PMC."""

try:
    from importlib.metadata import version as _pkg_version

    __version__ = _pkg_version("gxl-paperclip")
except Exception:
    __version__ = "0.0.0"
