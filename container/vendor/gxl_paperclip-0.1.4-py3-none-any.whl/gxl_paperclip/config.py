"""Configuration constants for Paperclip."""

from __future__ import annotations

import json
import os
from pathlib import Path

# ---------------------------------------------------------------------------
# Server base URL (widgets backend — hosts /api/cli)
# ---------------------------------------------------------------------------
DEFAULT_BASE_URL = os.getenv("PAPERCLIP_BASE_URL", "https://paperclip.gxl.ai")

# ---------------------------------------------------------------------------
# OAuth 2.0 Authentication
# ---------------------------------------------------------------------------
OAUTH_BASE_URL = os.getenv(
    "PAPERCLIP_OAUTH_URL",
    f"{DEFAULT_BASE_URL}/api/oauth",
)

# ---------------------------------------------------------------------------
# Local storage
# ---------------------------------------------------------------------------
PAPERCLIP_DIR = Path(os.getenv("PAPERCLIP_CONFIG_DIR", Path.home() / ".paperclip"))
CREDENTIALS_FILE = PAPERCLIP_DIR / "credentials.json"
CONFIG_FILE = PAPERCLIP_DIR / "config.json"


def get_base_url() -> str:
    """Resolve the effective server base URL.

    Checks config.json for a user-configured URL, falls back to
    DEFAULT_BASE_URL.  Kept here (not in cli.py) so that credentials.py
    can import it without circular dependencies.
    """
    if CONFIG_FILE.exists():
        try:
            state = json.loads(CONFIG_FILE.read_text())
        except (json.JSONDecodeError, OSError):
            state = {}
    else:
        state = {}

    if "base_url" in state:
        return state["base_url"].rstrip("/")
    mcp_url = state.get("mcp_url", "")
    if mcp_url and "/mcp/" in mcp_url:
        return mcp_url.split("/mcp/")[0]
    return DEFAULT_BASE_URL.rstrip("/")
