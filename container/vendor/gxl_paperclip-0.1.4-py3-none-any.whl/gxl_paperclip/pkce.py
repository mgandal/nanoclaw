"""PKCE (Proof Key for Code Exchange) utilities for OAuth 2.0.

Implements RFC 7636 for secure authorization code flow from CLI applications.
"""

import base64
import hashlib
import secrets


def generate_code_verifier(length: int = 128) -> str:
    """Generate a cryptographically random code verifier.

    Args:
        length: Length of the verifier (43-128 characters)

    Returns:
        Base64URL-encoded random string

    Raises:
        ValueError: If length is not between 43 and 128
    """
    if not 43 <= length <= 128:
        raise ValueError("Code verifier length must be between 43 and 128")

    # Generate random bytes and base64url encode
    random_bytes = secrets.token_bytes(96)  # 96 bytes → 128 base64url chars
    code_verifier = base64.urlsafe_b64encode(random_bytes).decode("utf-8")

    # Remove padding and truncate to desired length
    code_verifier = code_verifier.rstrip("=")[:length]

    return code_verifier


def generate_code_challenge(code_verifier: str) -> str:
    """Generate code challenge from code verifier using SHA256.

    Args:
        code_verifier: The code verifier string

    Returns:
        Base64URL-encoded SHA256 hash of the verifier
    """
    # Hash the verifier with SHA256
    digest = hashlib.sha256(code_verifier.encode("utf-8")).digest()

    # Base64URL encode and remove padding
    code_challenge = base64.urlsafe_b64encode(digest).decode("utf-8")
    code_challenge = code_challenge.rstrip("=")

    return code_challenge


def generate_state(length: int = 43) -> str:
    """Generate a random state parameter for CSRF protection.

    Args:
        length: Length of the state string

    Returns:
        Base64URL-encoded random string
    """
    random_bytes = secrets.token_bytes(32)
    state = base64.urlsafe_b64encode(random_bytes).decode("utf-8")
    state = state.rstrip("=")[:length]

    return state
