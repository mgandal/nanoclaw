"""Fetch and install Paperclip skill files for Claude Code, Cursor, or Codex."""

from __future__ import annotations

import sys
from pathlib import Path

import click

CYAN = "\033[96m"
GREEN = "\033[92m"
RED = "\033[91m"
BOLD = "\033[1m"
DIM = "\033[2m"
RESET = "\033[0m"
CLR = "\033[2K"

_CODEX_START = "<!-- paperclip-skill-start -->"
_CODEX_END = "<!-- paperclip-skill-end -->"

AGENTS = [
    {
        "key": "claude-code",
        "label": "Claude Code",
        "desc": ".claude/skills/paperclip/SKILL.md",
        "endpoint": "/skills/claude-code.md",
    },
    {
        "key": "cursor",
        "label": "Cursor",
        "desc": ".cursor/skills/paperclip/SKILL.md",
        "endpoint": "/skills/cursor.md",
    },
    {
        "key": "codex",
        "label": "Codex",
        "desc": ".agents/skills/paperclip/SKILL.md",
        "endpoint": "/skills/codex.md",
    },
]


# ── File writers ─────────────────────────────────────────────────


def _write_claude_code(content: str, target: Path) -> Path:
    skill_dir = target / ".claude" / "skills" / "paperclip"
    skill_dir.mkdir(parents=True, exist_ok=True)
    path = skill_dir / "SKILL.md"
    path.write_text(content)
    return path


def _write_cursor(content: str, target: Path) -> Path:
    skill_dir = target / ".cursor" / "skills" / "paperclip"
    skill_dir.mkdir(parents=True, exist_ok=True)
    path = skill_dir / "SKILL.md"
    path.write_text(content)
    return path


def _write_codex(content: str, target: Path) -> Path:
    skill_dir = target / ".agents" / "skills" / "paperclip"
    skill_dir.mkdir(parents=True, exist_ok=True)
    path = skill_dir / "SKILL.md"
    path.write_text(content)
    return path


def _write_codex_legacy(content: str, target: Path) -> Path:
    """Write to AGENTS.md with sentinel comments (legacy Codex format)."""
    path = target / "AGENTS.md"
    wrapped = f"{_CODEX_START}\n{content}\n{_CODEX_END}\n"

    if path.exists():
        existing = path.read_text()
        if _CODEX_START in existing:
            i = existing.index(_CODEX_START)
            j = existing.index(_CODEX_END) + len(_CODEX_END)
            nl = existing.find("\n", j)
            j = nl + 1 if nl != -1 else j
            path.write_text(existing[:i] + wrapped + existing[j:])
        else:
            with open(path, "a") as f:
                f.write("\n" + wrapped)
    else:
        path.write_text(wrapped)

    return path


# ── Multi-select checkbox ─────────────────────────────────────────


def _checkbox(options: list, title: str) -> list[int]:
    """Multi-select checkbox — arrows + space on TTY, comma-list fallback."""
    if not sys.stdin.isatty():
        return _checkbox_numbered(options, title)
    try:
        import termios  # noqa: F811
        import tty  # noqa: F811

        return _checkbox_arrows(options, title, termios, tty)
    except (ImportError, AttributeError):
        return _checkbox_numbered(options, title)


def _checkbox_numbered(options: list, title: str) -> list[int]:
    click.echo(f"\n  {BOLD}{title}{RESET}\n")
    for i, opt in enumerate(options):
        click.echo(f"    {i + 1}) {opt['label']}  {DIM}{opt['desc']}{RESET}")
    click.echo()
    while True:
        raw = click.prompt("  Select (e.g. 1,2 or all)", default="1")
        if raw.strip().lower() == "all":
            return list(range(len(options)))
        try:
            chosen = [int(x.strip()) - 1 for x in raw.split(",") if x.strip()]
            if chosen and all(0 <= v < len(options) for v in chosen):
                return list(dict.fromkeys(chosen))
        except ValueError:
            pass
        click.echo(
            f"  Enter numbers 1\u2013{len(options)} separated by commas, or 'all'"
        )


def _checkbox_arrows(options: list, title: str, termios, tty) -> list[int]:  # type: ignore[no-untyped-def]
    idx = 0
    n = len(options)
    selected: set[int] = set()
    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    lines = n

    def render(first: bool = False) -> None:
        if not first:
            sys.stdout.write(f"\033[{lines}A\r")
        for i, opt in enumerate(options):
            check = f"{GREEN}\u2713{RESET}" if i in selected else " "
            cursor = f"{CYAN}\u203a{RESET}" if i == idx else " "
            sys.stdout.write(
                f"{CLR}   {cursor} [{check}] {opt['label']}  {DIM}{opt['desc']}{RESET}\n"
            )
        sys.stdout.write(
            f"{CLR}  {DIM}\u2191/\u2193 navigate \u00b7 space select \u00b7 enter confirm \u00b7 q quit{RESET}"
        )
        sys.stdout.flush()

    click.echo(f"\n  {BOLD}{title}{RESET}\n")
    render(first=True)

    try:
        tty.setcbreak(fd)
        while True:
            ch = sys.stdin.read(1)
            if ch == "\x1b":
                b = sys.stdin.read(1)
                if b == "[":
                    arrow = sys.stdin.read(1)
                    if arrow == "A":
                        idx = (idx - 1) % n
                    elif arrow == "B":
                        idx = (idx + 1) % n
                render()
            elif ch == " ":
                if idx in selected:
                    selected.discard(idx)
                else:
                    selected.add(idx)
                render()
            elif ch in ("\r", "\n"):
                sys.stdout.write("\n\n")
                sys.stdout.flush()
                if not selected:
                    return [idx]
                return sorted(selected)
            elif ch in ("q", "\x03"):
                sys.stdout.write("\n")
                raise SystemExit(0)
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)


# ── Main entry ───────────────────────────────────────────────────


def install_skill(base_url: str, target_dir: str = ".") -> None:
    """Interactive TUI to fetch and install Paperclip skill."""
    import requests

    target = Path(target_dir).resolve()

    click.echo()
    click.echo(
        f"  {BOLD}\u256d\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u256e{RESET}"
    )
    click.echo(f"  {BOLD}\u2502    Paperclip  Install     \u2502{RESET}")
    click.echo(
        f"  {BOLD}\u2570\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u256f{RESET}"
    )

    choices = _checkbox(AGENTS, "Select your coding agent(s):")
    selected_agents = [AGENTS[i] for i in choices]

    click.echo(f"  {BOLD}Install directory{RESET}")
    dir_input = click.prompt("  Path", default=str(target), show_default=True)
    target = Path(dir_input).expanduser().resolve()

    if not target.is_dir():
        click.echo(f"\n  {RED}\u2717 Directory not found: {target}{RESET}")
        raise SystemExit(1)

    writers = {
        "claude-code": _write_claude_code,
        "cursor": _write_cursor,
        "codex": _write_codex,
    }

    installed_keys: list[str] = []
    for agent in selected_agents:
        click.echo(f"\n  Fetching skill for {BOLD}{agent['label']}{RESET} ...")
        try:
            resp = requests.get(f"{base_url}{agent['endpoint']}", timeout=15)
            resp.raise_for_status()
            content = resp.text
        except Exception as e:
            click.echo(
                f"  {RED}\u2717 Failed to fetch skill for {agent['label']}: {e}{RESET}"
            )
            continue

        path = writers[agent["key"]](content, target)
        click.echo(f"  {GREEN}\u2713{RESET} Installed to {BOLD}{path}{RESET}")
        installed_keys.append(agent["key"])

    if not installed_keys:
        click.echo(f"\n  {RED}\u2717 No skills were installed.{RESET}")
        raise SystemExit(1)

    # Reload reminder
    click.echo()
    click.echo(
        f"  {BOLD}Next step:{RESET} reload your coding session so the skill is picked up."
    )
    click.echo()
    if "cursor" in installed_keys:
        click.echo(
            f'  {DIM}\u2022 Cursor:{RESET}      Reload Window  (Cmd/Ctrl+Shift+P \u2192 "Reload Window")'
        )
    if "claude-code" in installed_keys:
        click.echo(
            f"  {DIM}\u2022 Claude Code:{RESET}  Start a new session or run /reload"
        )
    if "codex" in installed_keys:
        click.echo(f"  {DIM}\u2022 Codex:{RESET}        Start a new Codex session")

    # Example query
    click.echo()
    click.echo(f"  {BOLD}Try it out:{RESET}")
    click.echo(
        f'  From the CLI:      {CYAN}paperclip search "GLP-1 receptor agonists"{RESET}'
    )
    click.echo(
        f"  Prompt your agent: {DIM}using {RESET}{CYAN}/paperclip{RESET}{DIM}, search for recent papers on GLP-1 receptor agonists{RESET}"
    )
    click.echo()


def refresh_installed_skills(base_url: str, silent: bool = False) -> None:
    """Update any previously installed skill files.

    Called on login and periodically during command execution so users
    always have the latest skill content without re-running `paperclip install`.

    When silent=True, suppresses all output (used for background refresh).
    """
    import requests

    cwd = Path.cwd()
    targets: list[tuple[Path, str, str | None]] = []

    claude_path = cwd / ".claude" / "skills" / "paperclip" / "SKILL.md"
    if claude_path.exists():
        targets.append((claude_path, f"{base_url}/skills/claude-code.md", None))

    cursor_path = cwd / ".cursor" / "skills" / "paperclip" / "SKILL.md"
    if cursor_path.exists():
        targets.append((cursor_path, f"{base_url}/skills/cursor.md", None))

    # New Codex location: .agents/skills/paperclip/SKILL.md
    codex_path = cwd / ".agents" / "skills" / "paperclip" / "SKILL.md"
    if codex_path.exists():
        targets.append((codex_path, f"{base_url}/skills/codex.md", None))

    # Legacy Codex location: AGENTS.md with sentinel comments
    agents_path = cwd / "AGENTS.md"
    legacy_codex = agents_path.exists() and _CODEX_START in agents_path.read_text()
    if legacy_codex:
        targets.append((agents_path, f"{base_url}/skills/codex.md", "legacy_codex"))

    for path, url, kind in targets:
        try:
            content = requests.get(url, timeout=5).text
            if kind == "legacy_codex":
                _write_codex_legacy(content, cwd)
            else:
                path.write_text(content)
            if not silent:
                click.echo(f"  {DIM}Updated {path.relative_to(cwd)}{RESET}")
        except Exception:
            if not silent:
                click.echo(f"  {DIM}Could not update {path.relative_to(cwd)}{RESET}")


_SKILL_CHECK_FILE = Path.home() / ".paperclip" / ".last_skill_refresh"
_SKILL_REFRESH_INTERVAL = 4 * 3600  # 4 hours


def maybe_refresh_skills(base_url: str) -> None:
    """Silently refresh installed skill files if the cooldown has elapsed.

    Safe to call on every command — checks a timestamp file and only
    hits the network every 4 hours. All failures are swallowed.
    """
    import time

    try:
        if _SKILL_CHECK_FILE.exists():
            last = float(_SKILL_CHECK_FILE.read_text().strip())
            if time.time() - last < _SKILL_REFRESH_INTERVAL:
                return

        refresh_installed_skills(base_url, silent=True)

        _SKILL_CHECK_FILE.parent.mkdir(parents=True, exist_ok=True)
        _SKILL_CHECK_FILE.write_text(str(time.time()))
    except Exception:
        pass
