"""Paperclip — thin client.

All command logic and output formatting live server-side.
The CLI handles auth, config, and install locally;
everything else is sent to /api/cli/execute.
"""

from __future__ import annotations

import json
import logging
import re
import shlex
import sys

import click

from . import config
from .credentials import Credentials
from .login import run_login

GREEN = "\033[92m"
RED = "\033[91m"
YELLOW = "\033[93m"
CYAN = "\033[96m"
RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"
CLR = "\033[2K"

_ANSI_RE = re.compile(r"\033\[[0-9;]*m")
_RESULTS_PAGE_SIZE = 10


# ── Helpers ───────────────────────────────────────────────────────


def _load_state() -> dict:
    if config.CONFIG_FILE.exists():
        try:
            return json.loads(config.CONFIG_FILE.read_text())
        except (json.JSONDecodeError, OSError):
            return {}
    return {}


def _save_state(state: dict):
    config.PAPERCLIP_DIR.mkdir(parents=True, exist_ok=True)
    config.CONFIG_FILE.write_text(json.dumps(state, indent=2))


def _get_base_url() -> str:
    """Resolve the base API URL (the widgets backend origin)."""
    state = _load_state()
    if "base_url" in state:
        return state["base_url"].rstrip("/")
    # Backward compat: old configs stored mcp_url instead of base_url
    mcp_url = state.get("mcp_url", "")
    if mcp_url and "/mcp/" in mcp_url:
        return mcp_url.split("/mcp/")[0]
    return config.DEFAULT_BASE_URL.rstrip("/")


def _ensure_auth() -> Credentials:
    """Return valid credentials, triggering interactive login if needed."""
    creds = Credentials.load()
    if creds:
        return creds

    if not sys.stdin.isatty():
        click.echo(f"{RED}[error] Not authenticated. Run: paperclip login{RESET}", err=True)
        sys.exit(1)

    click.echo(f"{DIM}Not signed in — starting login...{RESET}")
    base = _get_base_url()
    creds = run_login(base_url=base)
    click.echo(f"{GREEN}✓{RESET} Authenticated as {BOLD}{creds.email}{RESET}\n")

    _maybe_install_skill(base)
    return creds


def _maybe_install_skill(base_url: str) -> None:
    """Offer to install the agent skill if none is detected in the current project."""
    from pathlib import Path

    cwd = Path.cwd()
    known_paths = [
        cwd / ".claude" / "skills" / "paperclip" / "SKILL.md",
        cwd / ".cursor" / "skills" / "paperclip" / "SKILL.md",
        cwd / ".agents" / "skills" / "paperclip" / "SKILL.md",
    ]
    if any(p.exists() for p in known_paths):
        from .skill import refresh_installed_skills
        try:
            refresh_installed_skills(base_url)
        except Exception:
            pass
        return

    if not sys.stdin.isatty():
        return

    if click.confirm(f"  Install Paperclip skill for your coding agent?", default=True):
        from .skill import install_skill
        install_skill(base_url)


def _get_headers() -> dict:
    h: dict = {"Content-Type": "application/json"}
    creds = _ensure_auth()
    h["Authorization"] = f"Bearer {creds.get_id_token()}"
    from . import __version__
    h["User-Agent"] = f"paperclip/{__version__}"
    return h


def _shell_join(args: tuple) -> str:
    """Re-join argv tokens with proper shell quoting."""
    return shlex.join(args)


def _execute(command: str, raw: str = ""):
    """Send a command to /api/cli/execute and print the formatted output."""
    import requests

    _SLOW_CMDS = {"map", "ask-image"}
    timeout = 300 if command in _SLOW_CMDS else 120

    base = _get_base_url()
    url = f"{base}/api/cli/execute"
    try:
        resp = requests.post(
            url,
            json={"command": command, "raw": raw},
            headers=_get_headers(),
            timeout=timeout,
        )
    except requests.ConnectionError:
        click.echo(f"{RED}[error] Cannot connect to {base}{RESET}", err=True)
        click.echo(f"{DIM}Run: paperclip config --url <URL>{RESET}", err=True)
        sys.exit(1)
    except requests.Timeout:
        click.echo(f"{RED}[error] Request timed out{RESET}", err=True)
        if command == "map":
            click.echo(f"{DIM}Tip: re-run search with -n 5 to limit papers, then map again.{RESET}", err=True)
        else:
            click.echo(f"{DIM}Try: narrower query, add --since 1y, or --source pmc{RESET}", err=True)
        sys.exit(1)

    if resp.status_code == 401 or resp.status_code == 403:
        Credentials.delete()
        click.echo(f"{DIM}Session expired — re-authenticating...{RESET}", err=True)
        _ensure_auth()
        click.echo(f"{DIM}Retrying...{RESET}", err=True)
        resp = requests.post(
            url,
            json={"command": command, "raw": raw},
            headers=_get_headers(),
            timeout=timeout,
        )
        if resp.status_code in (401, 403):
            click.echo(f"{RED}[error] Authentication failed.{RESET}", err=True)
            sys.exit(1)

    if resp.status_code == 429:
        click.echo(
            f"{YELLOW}[rate limit] Too many requests. Please wait a moment.{RESET}",
            err=True,
        )
        sys.exit(1)

    if resp.status_code != 200:
        try:
            detail = resp.json().get("detail", resp.text)
        except Exception:
            detail = resp.text[:500]
        click.echo(f"{RED}[error] {detail}{RESET}", err=True)
        sys.exit(1)

    data = resp.json()
    output = data.get("output", "")
    if output:
        click.echo(output)
    elapsed = data.get("elapsed_ms")
    result_id = data.get("result_id")
    if elapsed is not None:
        label = f"{elapsed}ms" if elapsed < 1000 else f"{elapsed / 1000:.1f}s"
        if result_id:
            click.echo(f"{DIM}[{label}, saved to {result_id}]{RESET}")
        else:
            click.echo(f"{DIM}[{label}]{RESET}")


# ── Dashboard ─────────────────────────────────────────────────────


def _show_dashboard():
    """Show status, recent results, and quick-start hints."""
    from . import __version__

    creds = Credentials.load()
    base = _get_base_url()

    click.echo()
    click.echo(f"  {BOLD}Paperclip{RESET} v{__version__}")
    rule = "\u2500" * 40
    click.echo(f"  {DIM}{rule}{RESET}")

    if creds:
        click.echo(f"  {GREEN}\u2713{RESET} Signed in as {BOLD}{creds.email}{RESET}")
        click.echo(f"  {DIM}Server: {base}{RESET}")
    else:
        click.echo(f"  {DIM}\u2717 Not signed in{RESET}")
        click.echo(f"  {DIM}Run any command to sign in automatically.{RESET}")
        click.echo()
        click.echo(f"  {BOLD}Try:{RESET}")
        click.echo(f'    paperclip search "protein design"')
        click.echo()
        return

    # Fetch recent results
    try:
        import requests

        resp = requests.get(
            f"{base}/api/cli/results",
            headers=_get_headers(),
            params={"limit": 5},
            timeout=5,
        )
        if resp.status_code == 200:
            rows = resp.json()
            if rows:
                click.echo()
                click.echo(f"  {BOLD}Recent searches{RESET}")
                for r in rows:
                    rid = r.get("result_id", "?")
                    raw = r.get("raw_input") or r.get("command", "")
                    if len(raw) > 55:
                        raw = raw[:52] + "..."
                    click.echo(f"    {CYAN}{rid}{RESET}  {raw}")
                click.echo(f"  {DIM}Run {RESET}{DIM}{BOLD}paperclip results{RESET}{DIM} to export searches{RESET}")
    except Exception:
        pass

    click.echo()
    click.echo(f"  {BOLD}Commands{RESET}")
    click.echo(f'    {CYAN}search{RESET}    Find papers          paperclip search "CRISPR delivery"')
    click.echo(f'    {CYAN}lookup{RESET}    Find by metadata     paperclip lookup doi 10.1101/...')
    click.echo(f'    {CYAN}grep{RESET}      Regex search         paperclip grep "kinase" /papers/<id>/content.lines')
    click.echo(f'    {CYAN}sql{RESET}       Query database       paperclip sql "SELECT title FROM documents ..."')
    click.echo(f'    {CYAN}cat{RESET}       Read file            paperclip cat /papers/<id>/meta.json')
    click.echo(f'    {CYAN}head{RESET}      Preview file         paperclip head -50 /papers/<id>/content.lines')
    click.echo(f'    {CYAN}ls{RESET}        List files           paperclip ls /papers/<id>/sections/')
    click.echo(f'    {CYAN}scan{RESET}      Multi-keyword find   paperclip scan /papers/<id>/content.lines "p53" "MDM2"')
    click.echo(f'    {CYAN}map{RESET}       Summarize papers     paperclip map "What methods were used?"')
    click.echo(f'    {CYAN}ask-image{RESET} Analyze figures      paperclip ask-image <id>/figures/fig1.jpg "Describe"')
    click.echo()


# ── Main group (with catch-all for bash commands) ─────────────────

_PASSTHROUGH = {"ignore_unknown_options": True, "allow_extra_args": True}


class _PaperclipGroup(click.Group):
    """Click group that forwards unrecognized subcommands as bash commands.

    Registered commands (login, search, lookup, …) take priority.
    Anything else (grep, cat, ls, head, …) gets sent to the server
    as a bash command via /api/cli/execute.
    """

    def get_command(self, ctx: click.Context, cmd_name: str):
        rv = super().get_command(ctx, cmd_name)
        if rv is not None:
            return rv
        return self._make_bash_proxy(cmd_name)

    @staticmethod
    def _make_bash_proxy(cmd_name: str) -> click.Command:
        @click.command(
            cmd_name,
            context_settings=_PASSTHROUGH,
            help=f"Run '{cmd_name}' on the paper filesystem.",
        )
        @click.argument("args", nargs=-1, type=click.UNPROCESSED)
        def proxy(args: tuple) -> None:
            _execute(cmd_name, _shell_join(args))

        return proxy

    def resolve_command(self, ctx: click.Context, args):
        # Prevent click from raising UsageError on unknown commands
        cmd_name = args[0] if args else None
        if cmd_name and not cmd_name.startswith("-"):
            cmd = self.get_command(ctx, cmd_name)
            if cmd is not None:
                return cmd_name, cmd, args[1:]
        return super().resolve_command(ctx, args)


@click.group(cls=_PaperclipGroup, invoke_without_command=True)
@click.version_option(package_name="gxl-paperclip")
@click.option("--debug", is_flag=True, help="Enable debug logging")
@click.pass_context
def main(ctx, debug: bool):
    """Paperclip — search 8M+ biomedical papers from the command line.

    \b
    Quick start:
        paperclip search "protein design"
        paperclip cat /papers/bio_dca47d15/meta.json
        paperclip grep -i "CRISPR" /papers/bio_dca47d15/content.lines

    Sign-in happens automatically on first use.
    """
    level = logging.DEBUG if debug else logging.WARNING
    logging.basicConfig(level=level, format="%(levelname)s: %(message)s")

    if ctx.invoked_subcommand is None:
        _show_dashboard()


# ── login (local) ─────────────────────────────────────────────────


@main.command()
def login():
    """Sign in to Paperclip via browser."""
    base = _get_base_url()
    creds = run_login(base_url=base)

    click.echo(f"\n{GREEN}✓{RESET} Authenticated as {BOLD}{creds.email}{RESET}")
    click.echo(f"  Server: {base}")

    _maybe_install_skill(base)


# ── logout (local) ────────────────────────────────────────────────


@main.command()
def logout():
    """Sign out and remove stored credentials."""
    config_removed = False
    creds_removed = False

    if config.CONFIG_FILE.exists():
        config.CONFIG_FILE.unlink()
        config_removed = True
    if Credentials.delete():
        creds_removed = True

    if config_removed or creds_removed:
        click.echo("Logged out. Credentials removed.")
    else:
        click.echo("No credentials found.")


# ── config (local) ────────────────────────────────────────────────


@main.command("config")
@click.option("--url", help="Set server base URL (e.g. http://localhost:8002)")
@click.option("--show", is_flag=True, help="Show current configuration")
def config_cmd(url: str | None, show: bool):
    """Configure Paperclip settings."""
    state = _load_state()

    if show or not url:
        base = _get_base_url()
        click.echo(f"Server:  {base}")
        if "base_url" not in state and "mcp_url" not in state:
            click.echo(f"  {YELLOW}(using default){RESET}")
        creds = Credentials.load()
        if creds:
            click.echo(f"Auth:    {GREEN}✓{RESET} {creds.email}")
        else:
            click.echo(f"Auth:    {YELLOW}✗{RESET} (run: paperclip login)")
        click.echo(f"Config:  {config.PAPERCLIP_DIR}")
        return

    state["base_url"] = url.rstrip("/")
    state.pop("mcp_url", None)
    _save_state(state)
    click.echo(f"{GREEN}✓{RESET} Server URL set: {url}")


# ── install (local) ───────────────────────────────────────────────


@main.command()
@click.option("--dir", "target_dir", default=".", help="Project directory")
def install(target_dir: str):
    """Install Paperclip skill for Claude Code or Codex."""
    from .skill import install_skill

    install_skill(_get_base_url(), target_dir)


# ── Server-proxied commands ───────────────────────────────────────
# search, lookup, sql, bash, grep, cat, head, etc. are all handled by
# _PaperclipGroup's catch-all proxy — no explicit registration needed.


# ── Results helpers ───────────────────────────────────────────────


def _strip_ansi(text: str) -> str:
    return _ANSI_RE.sub("", text)


def _parse_papers_from_output(output: str) -> list[dict]:
    """Parse formatted search/lookup output into paper records for CSV."""
    text = _strip_ansi(output)
    records: list[dict] = []

    entries = re.split(r"\n(?=\s+\d+\.\s)", text)
    for entry in entries:
        lines = entry.strip().split("\n")
        if not lines:
            continue
        m = re.match(r"\s*(\d+)\.\s+(.+)", lines[0])
        if not m:
            continue

        record: dict = {"title": m.group(2).strip()}
        remaining = [l.strip() for l in lines[1:] if l.strip()]

        for line in remaining:
            if line.startswith("https://"):
                record.setdefault("url", line)
            elif line.startswith("doi:"):
                record.setdefault("url", f"https://doi.org/{line[4:]}")
            elif line.startswith('"'):
                record["abstract"] = line.strip('"')
            elif "\u00b7" in line or "·" in line:
                sep = "\u00b7" if "\u00b7" in line else "·"
                parts = [p.strip() for p in line.split(sep)]
                if parts:
                    record["id"] = parts[0]
                if len(parts) >= 2:
                    record["source"] = parts[1]
                if len(parts) >= 3:
                    record["date"] = parts[2]
            elif "authors" not in record:
                record["authors"] = line

        records.append(record)
    return records


def _results_picker(rows: list[dict]) -> int | None:
    """Interactive paginated picker for saved results."""
    if not sys.stdin.isatty():
        return None
    try:
        import termios
        import tty
    except (ImportError, AttributeError):
        return None

    n = len(rows)
    page_size = min(_RESULTS_PAGE_SIZE, n)
    total_pages = (n + page_size - 1) // page_size
    idx = 0
    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    redraw_lines = page_size  # hint has no trailing \n so cursor stays on it

    def _desc(r: dict) -> str:
        raw = r.get("raw_input", r.get("command", ""))
        return raw[:45] + ("..." if len(raw) > 45 else "")

    def _ts(r: dict) -> str:
        return (r.get("created_at") or "")[:16].replace("T", " ")

    def render(first: bool = False) -> None:
        page = idx // page_size
        start = page * page_size
        end = min(start + page_size, n)

        if not first:
            sys.stdout.write(f"\033[{redraw_lines}A\r")

        for i in range(start, start + page_size):
            if i < end:
                r = rows[i]
                rid = r.get("result_id", "?")
                desc = _desc(r)
                ts = _ts(r)
                if i == idx:
                    sys.stdout.write(
                        f"{CLR}  {CYAN}\u203a {rid}{RESET}  {desc}  {DIM}{ts}{RESET}\n"
                    )
                else:
                    sys.stdout.write(
                        f"{CLR}    {DIM}{rid}{RESET}  {desc}  {DIM}{ts}{RESET}\n"
                    )
            else:
                sys.stdout.write(f"{CLR}\n")

        pg = f"page {page + 1}/{total_pages}" if total_pages > 1 else ""
        paging = "n/p page \u00b7 " if total_pages > 1 else ""
        sys.stdout.write(
            f"{CLR}  {DIM}\u2191/\u2193 navigate \u00b7 enter save \u00b7 {paging}q quit  {pg}{RESET}"
        )
        sys.stdout.flush()

    click.echo(f"\n  {BOLD}Paperclip Results{RESET}")
    rule = "\u2500" * 40
    click.echo(f"  {DIM}{rule}{RESET}")
    click.echo(f"  {n} saved result{'s' if n != 1 else ''}\n")
    render(first=True)

    try:
        tty.setcbreak(fd)
        while True:
            ch = sys.stdin.read(1)
            if ch == "\x1b":
                b = sys.stdin.read(1)
                if b == "[":
                    arrow = sys.stdin.read(1)
                    if arrow == "A":
                        idx = (idx - 1) % n
                    elif arrow == "B":
                        idx = (idx + 1) % n
                    render()
            elif ch in ("\r", "\n"):
                sys.stdout.write("\n\n")
                sys.stdout.flush()
                return idx
            elif ch == "n" and total_pages > 1:
                page = idx // page_size
                if page < total_pages - 1:
                    idx = (page + 1) * page_size
                    render()
            elif ch == "p" and total_pages > 1:
                page = idx // page_size
                if page > 0:
                    idx = (page - 1) * page_size
                    render()
            elif ch in ("q", "\x03"):
                sys.stdout.write("\n")
                sys.stdout.flush()
                return None
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)


# ── results command ───────────────────────────────────────────────


@main.command()
@click.argument("result_id", required=False, default=None)
@click.option("--list", "list_all", is_flag=True, help="Non-interactive list")
def results(result_id: str | None, list_all: bool):
    """Browse and export saved search results.

    \b
    Interactive mode (default):
        paperclip results

    Export a specific result:
        paperclip results s_4a2b61f6

    Non-interactive list:
        paperclip results --list
    """
    import csv
    from pathlib import Path

    import requests

    base = _get_base_url()
    headers = _get_headers()

    def _fetch_result(rid: str) -> dict | None:
        try:
            resp = requests.get(
                f"{base}/api/cli/results/{rid}", headers=headers, timeout=10
            )
        except requests.ConnectionError:
            click.echo(f"{RED}[error] Cannot connect to {base}{RESET}", err=True)
            return None
        if resp.status_code == 404:
            click.echo(f"{RED}[error] Result {rid} not found.{RESET}", err=True)
            return None
        if resp.status_code != 200:
            click.echo(f"{RED}[error] {resp.text[:200]}{RESET}", err=True)
            return None
        return resp.json()

    def _export(rid: str, data: dict) -> None:
        output = data.get("output", "")
        records = _parse_papers_from_output(output)
        raw_input = data.get("raw_input", data.get("command", ""))

        if raw_input:
            click.echo(f"  {DIM}Query: {raw_input}{RESET}")

        if not records:
            default_path = f"./{rid}.txt"
            path = click.prompt("  Save to", default=default_path)
            Path(path).expanduser().resolve().write_text(_strip_ansi(output))
            click.echo(f"  {GREEN}\u2713{RESET} Saved to {BOLD}{path}{RESET}")
            return

        default_path = f"./{rid}.csv"
        path = click.prompt("  Save to", default=default_path)
        dest = Path(path).expanduser().resolve()

        fieldnames = ["title", "authors", "id", "source", "date", "url", "abstract"]
        with open(dest, "w", newline="") as f:
            writer = csv.DictWriter(
                f, fieldnames=fieldnames, extrasaction="ignore"
            )
            writer.writeheader()
            writer.writerows(records)

        click.echo(
            f"  {GREEN}\u2713{RESET} Saved {len(records)} papers to {BOLD}{path}{RESET}"
        )

    # Direct export by result ID
    if result_id:
        data = _fetch_result(result_id)
        if data:
            _export(result_id, data)
        return

    # Fetch results list
    try:
        resp = requests.get(f"{base}/api/cli/results", headers=headers, timeout=10)
    except requests.ConnectionError:
        click.echo(f"{RED}[error] Cannot connect to {base}{RESET}", err=True)
        sys.exit(1)
    if resp.status_code != 200:
        click.echo(f"{RED}[error] {resp.text[:200]}{RESET}", err=True)
        sys.exit(1)
    rows = resp.json()
    if not rows:
        click.echo(f"{DIM}No saved results. Run a search or map first.{RESET}")
        return

    # Non-interactive list
    if list_all or not sys.stdin.isatty():
        click.echo(f"{BOLD}Recent results ({len(rows)}):{RESET}\n")
        for r in rows:
            rid = r.get("result_id", "?")
            raw = r.get("raw_input", r.get("command", ""))
            ts = (r.get("created_at") or "")[:16].replace("T", " ")
            click.echo(f"  {rid}  {DIM}{raw}  {ts}{RESET}")
        return

    # Interactive picker
    choice = _results_picker(rows)
    if choice is None:
        return

    selected = rows[choice]
    rid = selected["result_id"]
    data = _fetch_result(rid)
    if data:
        _export(rid, data)


if __name__ == "__main__":
    main()
