"""Paperclip — Paper CLI for Preprints + PMC."""

__version__ = "0.1.0"
