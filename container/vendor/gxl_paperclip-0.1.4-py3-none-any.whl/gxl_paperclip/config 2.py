"""Configuration constants for Paperclip."""

import os
from pathlib import Path

# ---------------------------------------------------------------------------
# Firebase (public Web API key — safe to embed in clients per Google docs,
# but MUST have HTTP referrer / API restrictions set in Google Cloud Console
# to prevent quota abuse and key misuse)
# ---------------------------------------------------------------------------
FIREBASE_API_KEY = os.getenv(
    "PAPERCLIP_FIREBASE_API_KEY", "AIzaSyBHMF4TFjucO6eOYSwQQD6VfHfNM-bIt5E"
)
FIREBASE_TOKEN_URL = (
    f"https://securetoken.googleapis.com/v1/token?key={FIREBASE_API_KEY}"
)

# ---------------------------------------------------------------------------
# Server base URL (widgets backend — hosts /api/cli)
# ---------------------------------------------------------------------------
DEFAULT_BASE_URL = os.getenv("PAPERCLIP_BASE_URL", "https://sy.staging.gxl.ai")

# ---------------------------------------------------------------------------
# OAuth 2.0 Authentication
# ---------------------------------------------------------------------------
OAUTH_BASE_URL = os.getenv(
    "PAPERCLIP_OAUTH_URL",
    f"{DEFAULT_BASE_URL}/api/oauth",
)

# ---------------------------------------------------------------------------
# Local storage
# ---------------------------------------------------------------------------
PAPERCLIP_DIR = Path(os.getenv("PAPERCLIP_CONFIG_DIR", Path.home() / ".paperclip"))
CREDENTIALS_FILE = PAPERCLIP_DIR / "credentials.json"
CONFIG_FILE = PAPERCLIP_DIR / "config.json"
