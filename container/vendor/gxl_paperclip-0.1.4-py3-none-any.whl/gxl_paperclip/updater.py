"""Self-update mechanism for the Paperclip CLI."""

from __future__ import annotations

import json
import logging
import os
import shutil
import sys
import tempfile
import time
import zipfile
from pathlib import Path

from . import __version__
from .config import PAPERCLIP_DIR

_UPDATE_CHECK_FILE = PAPERCLIP_DIR / ".last_update_check"
_UPDATE_LOCK_FILE = PAPERCLIP_DIR / ".update_lock"
_CHECK_INTERVAL = 4 * 3600  # 4 hours between background checks

logger = logging.getLogger(__name__)


def _parse_version(v: str) -> tuple[int, ...]:
    """Parse a dotted version string into a comparable tuple."""
    try:
        return tuple(int(x) for x in v.strip().split("."))
    except (ValueError, AttributeError):
        return (0,)


def is_managed_install() -> bool:
    """Return True if Paperclip was installed via install.sh into ~/.paperclip/lib/.

    If the user installed via pip or pip -e, the update mechanism should not
    try to overwrite the installation.
    """
    lib_dir = PAPERCLIP_DIR / "lib"
    if not lib_dir.is_dir():
        return False
    pkg_init = lib_dir / "gxl_paperclip" / "__init__.py"
    return pkg_init.exists()


def fetch_latest_version(base_url: str) -> str | None:
    """Fetch the latest published CLI version from the server.

    Returns the version string or None on failure.
    """
    import requests

    try:
        resp = requests.get(f"{base_url}/version.json", timeout=5)
        if resp.status_code == 200:
            data = resp.json()
            return data.get("version")
    except Exception:
        return None
    return None


def needs_update(latest: str) -> bool:
    return _parse_version(latest) > _parse_version(__version__)


# ── Background (cached) check ────────────────────────────────────


def _read_cached_check() -> dict | None:
    try:
        if _UPDATE_CHECK_FILE.exists():
            return json.loads(_UPDATE_CHECK_FILE.read_text())
    except Exception:
        pass
    return None


def _write_cached_check(latest: str) -> None:
    try:
        PAPERCLIP_DIR.mkdir(parents=True, exist_ok=True)
        _UPDATE_CHECK_FILE.write_text(
            json.dumps({"latest": latest, "checked_at": time.time()})
        )
    except Exception:
        pass


def check_update_available(base_url: str) -> str | None:
    """Non-blocking cached check. Returns latest version if an update exists, else None.

    Respects a cooldown so repeated CLI invocations don't hammer the server.
    """
    cached = _read_cached_check()
    if cached:
        checked_at = cached.get("checked_at", 0)
        if time.time() - checked_at < _CHECK_INTERVAL:
            latest = cached.get("latest", "")
            return latest if needs_update(latest) else None

    latest = fetch_latest_version(base_url)
    if latest:
        _write_cached_check(latest)
        return latest if needs_update(latest) else None
    return None


# ── Perform update ────────────────────────────────────────────────


def perform_update(base_url: str) -> tuple[bool, str]:
    """Download the latest wheel and install it into ~/.paperclip/lib/.

    Returns (success, message).
    """
    import requests

    lib_dir = PAPERCLIP_DIR / "lib"
    whl_url = f"{base_url}/paperclip.whl"

    with tempfile.TemporaryDirectory() as tmpdir:
        whl_path = Path(tmpdir) / "paperclip.whl"

        try:
            resp = requests.get(whl_url, timeout=30, stream=True)
            resp.raise_for_status()
        except requests.ConnectionError:
            return False, f"Cannot connect to {base_url}"
        except requests.HTTPError as e:
            return False, f"Download failed: {e}"
        except requests.Timeout:
            return False, "Download timed out"

        with open(whl_path, "wb") as f:
            for chunk in resp.iter_content(chunk_size=8192):
                f.write(chunk)

        try:
            with zipfile.ZipFile(whl_path) as zf:
                # Validate: must contain gxl_paperclip
                names = zf.namelist()
                if not any("gxl_paperclip" in n for n in names):
                    return False, "Invalid wheel: missing gxl_paperclip package"

                # Safety: validate all paths resolve inside lib_dir
                real_lib = os.path.realpath(str(lib_dir))
                for member in names:
                    resolved = os.path.realpath(os.path.join(real_lib, member))
                    if not resolved.startswith(real_lib + os.sep) and resolved != real_lib:
                        return False, f"Unsafe path in wheel: {member}"

                # Remove old gxl_paperclip package and dist-info, keep deps
                for child in lib_dir.iterdir():
                    if child.name.startswith("gxl_paperclip") or child.name.startswith("gxl-paperclip"):
                        if child.is_dir():
                            shutil.rmtree(child)
                        else:
                            child.unlink()

                zf.extractall(lib_dir)
        except zipfile.BadZipFile:
            return False, "Downloaded file is not a valid wheel"

    import re

    # Read the new version from the extracted dist-info METADATA
    new_version = "unknown"
    for child in lib_dir.iterdir():
        if child.name.startswith("gxl_paperclip") and child.name.endswith(".dist-info"):
            metadata = child / "METADATA"
            if metadata.exists():
                m = re.search(r"^Version:\s*(.+)", metadata.read_text(), re.MULTILINE)
                if m:
                    new_version = m.group(1).strip()
            break

    # Invalidate the cached check so the dashboard doesn't keep nagging
    if _UPDATE_CHECK_FILE.exists():
        try:
            _UPDATE_CHECK_FILE.unlink()
        except Exception:
            pass

    return True, new_version


# ── Silent auto-update for agent use ─────────────────────────────


def auto_update(base_url: str) -> bool:
    """Check for updates and silently install if available.

    Returns True if an update was installed (caller should re-exec).

    Designed to be called before every command. Safe to call frequently:
    - Respects the 4-hour cache so the server is only hit occasionally
    - Uses a lockfile to prevent concurrent updates
    - Only updates managed installs (~/.paperclip/lib/)
    - Never raises — all failures are swallowed so commands aren't blocked
    """
    try:
        if not is_managed_install():
            return False

        latest = check_update_available(base_url)
        if not latest:
            return False

        # Acquire a simple lockfile to prevent parallel updates
        lock = _UPDATE_LOCK_FILE
        try:
            fd = os.open(str(lock), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            os.write(fd, str(os.getpid()).encode())
            os.close(fd)
        except FileExistsError:
            # Another process is updating — check staleness (>5 min = stale)
            try:
                if time.time() - lock.stat().st_mtime > 300:
                    lock.unlink()
                else:
                    return False
            except OSError:
                return False
            # Retry acquire after clearing stale lock
            try:
                fd = os.open(str(lock), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                os.write(fd, str(os.getpid()).encode())
                os.close(fd)
            except FileExistsError:
                return False

        try:
            ok, msg = perform_update(base_url)
            if ok:
                print(
                    f"\033[2m[paperclip] Updated {__version__} → v{msg}\033[0m",
                    file=sys.stderr,
                )
                return True
            else:
                logger.debug("Auto-update failed: %s", msg)
                return False
        finally:
            try:
                lock.unlink()
            except OSError:
                pass

    except Exception:
        return False
