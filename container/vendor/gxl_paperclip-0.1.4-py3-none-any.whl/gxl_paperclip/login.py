"""Browser-based OAuth 2.0 PKCE login flow for Paperclip.

Implements RFC 7636 authorization code flow with PKCE:
1. Generate code_verifier and code_challenge (PKCE)
2. Start localhost HTTP server to receive authorization code
3. Open browser to /oauth/authorize with code_challenge
4. User authenticates via Firebase on web
5. Web redirects to localhost/callback with authorization code
6. Exchange code + code_verifier for Firebase tokens
7. Store credentials in ~/.paperclip/credentials.json
"""

from __future__ import annotations

import base64
import datetime
import json
import logging
import os
import socket
import sys
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Optional
from urllib.parse import parse_qs, urlencode, urlparse

import requests

from . import config
from .credentials import Credentials
from .pkce import generate_code_challenge, generate_code_verifier, generate_state

logger = logging.getLogger(__name__)


_PREFERRED_CALLBACK_PORT = 18457


def _find_free_port() -> int:
    """Find a free port for the OAuth callback server.

    Prefers a fixed port so that devcontainer/codespace port forwarding
    can be pre-configured, avoiding slow auto-detection of ephemeral ports.
    Falls back to a random port if the preferred one is occupied.
    """
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.bind(("127.0.0.1", _PREFERRED_CALLBACK_PORT))
            return _PREFERRED_CALLBACK_PORT
        except OSError:
            s.bind(("127.0.0.1", 0))
            return s.getsockname()[1]


def _is_remote_env() -> bool:
    return bool(
        os.getenv("CODESPACES")
        or os.getenv("REMOTE_CONTAINERS")
        or os.getenv("VSCODE_REMOTE_CONTAINERS_SESSION")
        or os.path.exists("/.dockerenv")
        or os.path.exists("/workspaces")
    )


class _CallbackResult:
    def __init__(self) -> None:
        self.authorization_code: Optional[str] = None
        self.state_received: Optional[str] = None
        self.error: Optional[str] = None
        self.done = threading.Event()


def run_login(base_url: Optional[str] = None) -> Credentials:
    """Run the interactive login flow. Uses device-code everywhere."""
    return _run_device_code_login(base_url)


def _run_device_code_login(base_url: Optional[str] = None) -> Credentials:
    """Device-code login: CLI shows a code, user enters it on the website."""
    api_base = f"{base_url.rstrip('/')}/api/oauth" if base_url else config.OAUTH_BASE_URL
    web_base = base_url.rstrip("/") if base_url else "https://paperclip.gxl.ai"

    code_verifier = generate_code_verifier()

    try:
        with open("/dev/tty", "r") as tty:
            sys.stdout.write("  Press Enter to log into GXL... ")
            sys.stdout.flush()
            tty.readline()
    except OSError:
        pass

    try:
        resp = requests.post(
            f"{api_base}/device",
            json={"code_verifier": code_verifier},
            timeout=15,
        )
        resp.raise_for_status()
        data = resp.json()
    except Exception as exc:
        print(f"Failed to start login: {exc}", file=sys.stderr)
        sys.exit(1)

    user_code = data["user_code"]
    device_code = data["device_code"]
    verify_url = f"{web_base}/login?device=true"

    BOLD = "\033[1m"
    CYAN = "\033[96m"
    UNDERLINE = "\033[4m"
    DIM = "\033[2m"
    RST = "\033[0m"

    print(f"\n  Your code:  {BOLD}{CYAN}{user_code}{RST}\n")
    print(f"  Open this link and enter the code to sign in:")
    print(f"  {BOLD}{UNDERLINE}{verify_url}{RST}\n")

    if not _is_remote_env():
        webbrowser.open(verify_url)

    print(f"{DIM}Waiting for sign-in...{RST}")

    deadline = time.time() + 300
    interval = 2
    while time.time() < deadline:
        time.sleep(interval)
        try:
            poll = requests.get(
                f"{api_base}/device/poll",
                params={"device_code": device_code},
                timeout=10,
            )
            if poll.status_code == 200:
                result = poll.json()
                if result.get("status") == "complete":
                    email = result.get("email", "")
                    uid = result.get("uid", "")
                    expires_in = int(result.get("expires_in", 3600))
                    creds = Credentials(
                        refresh_token=result["refresh_token"],
                        email=email,
                        uid=uid,
                        id_token=result["id_token"],
                        id_token_expires_at=time.time() + expires_in,
                        created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                    )
                    creds.save()
                    return creds
            elif poll.status_code == 400:
                print("Code expired. Please try again.", file=sys.stderr)
                sys.exit(1)
        except requests.exceptions.RequestException:
            pass

    print("Login timed out.", file=sys.stderr)
    sys.exit(1)


def _run_pkce_login(base_url: Optional[str] = None) -> Credentials:
    """PKCE login with localhost callback — used on local machines."""
    oauth_base = f"{base_url.rstrip('/')}/api/oauth" if base_url else config.OAUTH_BASE_URL

    port = _find_free_port()
    result = _CallbackResult()

    code_verifier = generate_code_verifier()
    code_challenge = generate_code_challenge(code_verifier)
    state = generate_state()

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, format, *args):
            pass

        def do_GET(self):
            parsed = urlparse(self.path)

            if parsed.path == "/callback":
                params = parse_qs(parsed.query)

                code = (params.get("code") or [""])[0]
                state_received = (params.get("state") or [""])[0]
                error = (params.get("error") or [""])[0]

                if error:
                    result.error = f"Authorization failed: {error}"
                    html = _error_html(f"Authorization failed: {error}")
                elif not code:
                    result.error = "No authorization code received"
                    html = _error_html("Authentication failed — no code received.")
                else:
                    result.authorization_code = code
                    result.state_received = state_received
                    html = _success_html()

                self.send_response(200)
                self.send_header("Content-Type", "text/html")
                self.end_headers()
                self.wfile.write(html.encode())
                result.done.set()

            else:
                self.send_response(404)
                self.end_headers()

    httpd = HTTPServer(("127.0.0.1", port), Handler)
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()

    callback_url = f"http://localhost:{port}/callback"

    auth_params = {
        "response_type": "code",
        "redirect_uri": callback_url,
        "code_challenge": code_challenge,
        "code_challenge_method": "S256",
        "state": state,
    }
    auth_url = f"{oauth_base}/authorize?{urlencode(auth_params)}"

    try:
        with open("/dev/tty", "r") as tty:
            sys.stdout.write("  Press Enter to log into GXL... ")
            sys.stdout.flush()
            tty.readline()
    except OSError:
        pass

    print(f"\nOpening browser...\n")
    if not webbrowser.open(auth_url):
        print("Could not open browser. Please visit the URL above manually.")
        print(f"  {auth_url}")

    print("Waiting for sign-in...")
    result.done.wait(timeout=300)

    try:
        httpd.server_close()
    except Exception:
        pass
    threading.Thread(target=httpd.shutdown, daemon=True).start()

    if not result.done.is_set():
        print("Login timed out.", file=sys.stderr)
        sys.exit(1)

    if result.error:
        print(f"Login failed: {result.error}", file=sys.stderr)
        sys.exit(1)

    if result.state_received != state:
        print("Security error: State parameter mismatch", file=sys.stderr)
        sys.exit(1)

    print("Exchanging authorization code for tokens...")
    try:
        token_response = requests.post(
            f"{oauth_base}/token",
            json={
                "code": result.authorization_code,
                "code_verifier": code_verifier,
                "redirect_uri": callback_url,
            },
            timeout=30,
        )
        token_response.raise_for_status()
        tokens = token_response.json()

        email, uid = _parse_jwt_claims(tokens["id_token"])
        expires_in = int(tokens.get("expires_in", 3600))
        creds = Credentials(
            refresh_token=tokens["refresh_token"],
            email=email,
            uid=uid,
            id_token=tokens["id_token"],
            id_token_expires_at=time.time() + expires_in,
            created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        )

    except requests.exceptions.RequestException as exc:
        print(f"Token exchange failed: {exc}", file=sys.stderr)
        sys.exit(1)

    creds.save()
    return creds


def _parse_jwt_claims(id_token: str) -> tuple[str, str]:
    """Extract email and uid from a Firebase ID token without verification.

    We trust the token because we just received it from our own server.
    """
    try:
        payload_b64 = id_token.split(".")[1]
        padding = 4 - len(payload_b64) % 4
        payload_b64 += "=" * padding
        claims = json.loads(base64.urlsafe_b64decode(payload_b64))
        return claims.get("email", ""), claims.get("user_id", claims.get("sub", ""))
    except Exception:
        return "", ""


def _success_html() -> str:
    return """\
<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8" /><title>Paperclip — Authenticated</title>
<style>
  body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    background: #f9fafb; color: #111827;
    display: flex; align-items: center; justify-content: center; min-height: 100vh;
  }
  .card {
    background: #fff; border-radius: 12px; padding: 2.5rem;
    text-align: center; max-width: 420px;
    box-shadow: 0 1px 3px rgba(0,0,0,.1), 0 1px 2px rgba(0,0,0,.06);
  }
  .check { font-size: 3rem; margin-bottom: 1rem; color: #22c55e; }
  h1 { font-size: 1.3rem; margin-bottom: .5rem; }
  p { color: #6b7280; }
</style>
</head>
<body>
<div class="card">
  <div class="check">&#10003;</div>
  <h1>Authenticated</h1>
  <p>You can close this tab and return to your terminal.</p>
</div>
</body>
</html>"""


def _error_html(message: str) -> str:
    import html

    safe_message = html.escape(message)
    return f"""\
<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8" /><title>Paperclip — Error</title>
<style>
  body {{
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    background: #f9fafb; color: #111827;
    display: flex; align-items: center; justify-content: center; min-height: 100vh;
  }}
  .card {{
    background: #fff; border-radius: 12px; padding: 2.5rem;
    text-align: center; max-width: 420px;
    box-shadow: 0 1px 3px rgba(0,0,0,.1), 0 1px 2px rgba(0,0,0,.06);
  }}
  .icon {{ font-size: 3rem; margin-bottom: 1rem; color: #ef4444; }}
  h1 {{ font-size: 1.3rem; margin-bottom: .5rem; }}
  p {{ color: #6b7280; }}
</style>
</head>
<body>
<div class="card">
  <div class="icon">&#10007;</div>
  <h1>Authentication Failed</h1>
  <p>{safe_message}</p>
</div>
</body>
</html>"""
