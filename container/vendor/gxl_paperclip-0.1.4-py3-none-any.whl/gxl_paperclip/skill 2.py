"""Fetch and install Paperclip skill files for Claude Code, Cursor, or Codex."""

from __future__ import annotations

import sys
from pathlib import Path

import click

CYAN = "\033[96m"
GREEN = "\033[92m"
RED = "\033[91m"
BOLD = "\033[1m"
DIM = "\033[2m"
RESET = "\033[0m"
CLR = "\033[2K"

_CODEX_START = "<!-- paperclip-skill-start -->"
_CODEX_END = "<!-- paperclip-skill-end -->"

AGENTS = [
    {
        "key": "claude-code",
        "label": "Claude Code",
        "desc": ".claude/skills/paperclip/SKILL.md",
        "endpoint": "/skills/claude-code.md",
    },
    {
        "key": "cursor",
        "label": "Cursor",
        "desc": ".cursor/skills/paperclip/SKILL.md",
        "endpoint": "/skills/cursor.md",
    },
    {
        "key": "codex",
        "label": "Codex",
        "desc": ".agents/skills/paperclip/SKILL.md",
        "endpoint": "/skills/codex.md",
    },
]


# ── File writers ─────────────────────────────────────────────────


def _write_claude_code(content: str, target: Path) -> Path:
    skill_dir = target / ".claude" / "skills" / "paperclip"
    skill_dir.mkdir(parents=True, exist_ok=True)
    path = skill_dir / "SKILL.md"
    path.write_text(content)
    return path


def _write_cursor(content: str, target: Path) -> Path:
    skill_dir = target / ".cursor" / "skills" / "paperclip"
    skill_dir.mkdir(parents=True, exist_ok=True)
    path = skill_dir / "SKILL.md"
    path.write_text(content)
    return path


def _write_codex(content: str, target: Path) -> Path:
    skill_dir = target / ".agents" / "skills" / "paperclip"
    skill_dir.mkdir(parents=True, exist_ok=True)
    path = skill_dir / "SKILL.md"
    path.write_text(content)
    return path


def _write_codex_legacy(content: str, target: Path) -> Path:
    """Write to AGENTS.md with sentinel comments (legacy Codex format)."""
    path = target / "AGENTS.md"
    wrapped = f"{_CODEX_START}\n{content}\n{_CODEX_END}\n"

    if path.exists():
        existing = path.read_text()
        if _CODEX_START in existing:
            i = existing.index(_CODEX_START)
            j = existing.index(_CODEX_END) + len(_CODEX_END)
            nl = existing.find("\n", j)
            j = nl + 1 if nl != -1 else j
            path.write_text(existing[:i] + wrapped + existing[j:])
        else:
            with open(path, "a") as f:
                f.write("\n" + wrapped)
    else:
        path.write_text(wrapped)

    return path


# ── Arrow-key picker ─────────────────────────────────────────────


def _pick(options: list, title: str) -> int:
    """Interactive picker — arrows on TTY, numbered fallback otherwise."""
    if not sys.stdin.isatty():
        return _pick_numbered(options, title)
    try:
        import termios  # noqa: F811
        import tty  # noqa: F811

        return _pick_arrows(options, title, termios, tty)
    except (ImportError, AttributeError):
        return _pick_numbered(options, title)


def _pick_numbered(options: list, title: str) -> int:
    click.echo(f"\n  {BOLD}{title}{RESET}\n")
    for i, opt in enumerate(options):
        click.echo(f"    {i + 1}) {opt['label']}  {DIM}{opt['desc']}{RESET}")
    click.echo()
    while True:
        raw = click.prompt("  Choice", default="1")
        try:
            v = int(raw)
            if 1 <= v <= len(options):
                return v - 1
        except ValueError:
            pass
        click.echo(f"  Enter 1\u2013{len(options)}")


def _pick_arrows(options: list, title: str, termios, tty) -> int:  # type: ignore[no-untyped-def]
    idx = 0
    n = len(options)
    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    lines = n  # move up past options only; hint has no trailing \n so cursor stays on it

    def render(first: bool = False) -> None:
        if not first:
            sys.stdout.write(f"\033[{lines}A\r")
        for i, opt in enumerate(options):
            if i == idx:
                sys.stdout.write(
                    f"{CLR}    {CYAN}\u203a {opt['label']}{RESET}  {DIM}{opt['desc']}{RESET}\n"
                )
            else:
                sys.stdout.write(
                    f"{CLR}      {opt['label']}  {DIM}{opt['desc']}{RESET}\n"
                )
        sys.stdout.write(
            f"{CLR}  {DIM}\u2191/\u2193 navigate \u00b7 enter select \u00b7 q quit{RESET}"
        )
        sys.stdout.flush()

    click.echo(f"\n  {BOLD}{title}{RESET}\n")
    render(first=True)

    try:
        tty.setcbreak(fd)
        while True:
            ch = sys.stdin.read(1)
            if ch == "\x1b":
                b = sys.stdin.read(1)
                if b == "[":
                    arrow = sys.stdin.read(1)
                    if arrow == "A":
                        idx = (idx - 1) % n
                    elif arrow == "B":
                        idx = (idx + 1) % n
                render()
            elif ch in ("\r", "\n"):
                sys.stdout.write("\n\n")
                sys.stdout.flush()
                return idx
            elif ch in ("q", "\x03"):
                sys.stdout.write("\n")
                raise SystemExit(0)
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)


# ── Main entry ───────────────────────────────────────────────────


def install_skill(base_url: str, target_dir: str = ".") -> None:
    """Interactive TUI to fetch and install Paperclip skill."""
    import requests

    target = Path(target_dir).resolve()

    click.echo()
    click.echo(
        f"  {BOLD}\u256d\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u256e{RESET}"
    )
    click.echo(f"  {BOLD}\u2502    Paperclip  Install     \u2502{RESET}")
    click.echo(
        f"  {BOLD}\u2570\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u256f{RESET}"
    )

    choice = _pick(AGENTS, "Select your coding agent:")
    agent = AGENTS[choice]

    click.echo(f"  {BOLD}Install directory{RESET}")
    dir_input = click.prompt("  Path", default=str(target), show_default=True)
    target = Path(dir_input).expanduser().resolve()

    if not target.is_dir():
        click.echo(f"\n  {RED}\u2717 Directory not found: {target}{RESET}")
        raise SystemExit(1)

    click.echo(f"\n  Fetching skill from {DIM}{base_url}{agent['endpoint']}{RESET} ...")

    try:
        resp = requests.get(f"{base_url}{agent['endpoint']}", timeout=15)
        resp.raise_for_status()
        content = resp.text
    except Exception as e:
        click.echo(f"  {RED}\u2717 Failed to fetch skill: {e}{RESET}")
        raise SystemExit(1)

    writers = {
        "claude-code": _write_claude_code,
        "cursor": _write_cursor,
        "codex": _write_codex,
    }
    path = writers[agent["key"]](content, target)

    click.echo(f"  {GREEN}\u2713{RESET} Installed to {BOLD}{path}{RESET}")
    click.echo()

    if agent["key"] == "claude-code":
        click.echo(f"  The skill loads automatically in Claude Code.")
        click.echo(
            f"  Use {CYAN}/paperclip{RESET} or just ask Claude to search papers."
        )
    elif agent["key"] == "cursor":
        click.echo(f"  The skill loads automatically in Cursor.")
        click.echo(
            f"  Just ask Cursor to search papers \u2014 it will see the instructions."
        )
    else:
        click.echo(f"  Codex discovers skills in .agents/skills/ automatically.")
        click.echo(
            f"  Use {CYAN}$paperclip{RESET} or just ask Codex to search papers."
        )

    click.echo()


def refresh_installed_skills(base_url: str) -> None:
    """Update any previously installed skill files.

    Called on login so users always have the latest skill content
    without needing to re-run `paperclip install`.
    """
    import requests

    cwd = Path.cwd()
    targets: list[tuple[Path, str, str | None]] = []

    claude_path = cwd / ".claude" / "skills" / "paperclip" / "SKILL.md"
    if claude_path.exists():
        targets.append((claude_path, f"{base_url}/skills/claude-code.md", None))

    cursor_path = cwd / ".cursor" / "skills" / "paperclip" / "SKILL.md"
    if cursor_path.exists():
        targets.append((cursor_path, f"{base_url}/skills/cursor.md", None))

    # New Codex location: .agents/skills/paperclip/SKILL.md
    codex_path = cwd / ".agents" / "skills" / "paperclip" / "SKILL.md"
    if codex_path.exists():
        targets.append((codex_path, f"{base_url}/skills/codex.md", None))

    # Legacy Codex location: AGENTS.md with sentinel comments
    agents_path = cwd / "AGENTS.md"
    legacy_codex = agents_path.exists() and _CODEX_START in agents_path.read_text()
    if legacy_codex:
        targets.append((agents_path, f"{base_url}/skills/codex.md", "legacy_codex"))

    for path, url, kind in targets:
        try:
            content = requests.get(url, timeout=5).text
            if kind == "legacy_codex":
                _write_codex_legacy(content, cwd)
            else:
                path.write_text(content)
            click.echo(f"  {DIM}Updated {path.relative_to(cwd)}{RESET}")
        except Exception:
            click.echo(f"  {DIM}Could not update {path.relative_to(cwd)}{RESET}")
